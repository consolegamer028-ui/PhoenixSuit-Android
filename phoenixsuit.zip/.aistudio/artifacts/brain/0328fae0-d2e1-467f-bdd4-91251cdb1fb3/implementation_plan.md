# Allwinner FEL PhoenixSuit Flasher

A dedicated Android utility and graphical interface for flashing Allwinner-based TV boxes (H616, H313, H6, H3) and ARM single-board computers via USB OTG. The app provides a direct USB Host protocol engine for Allwinner BROM/FEL mode and PhoenixSuit packets, combined with an automated Termux bridge, live partition backup manager, pre-flash safety validator, partition flasher, and integrity verification reboot tool.

### User Review & Critical Decisions

> [!IMPORTANT]
> The flasher supports dual operational modes: direct Android USB Host OTG (which communicates directly with the Allwinner BROM chip via USB endpoints without requiring root permissions) and an automated Termux bridge script runner for advanced users who prefer executing `sunxi-tools` or `phoenixsuit` command-line binaries in proot.

- **Confirmed Communication Mode**: Hybrid architecture featuring both a built-in Android USB Host engine (direct FEL/PhoenixSuit low-level packets over USB OTG) and a companion Termux command & script execution bridge.
- **Confirmed Target Devices**: Allwinner TV boxes focusing on modern H616, H313, and H6 platforms, with support for SlimboxTV images (`.img`, raw partition dumps, and PhoenixSuit sparse archives).
- **Confirmed Backup Storage**: Custom folder destination selected by the user via the Android Storage Access Framework (SAF) system document picker, with pre-flight storage capacity checks.

---

### 1. Overview & Core Concept

- **What It Does**: Connects an Android phone/tablet to an Allwinner TV box via a standard USB OTG cable while the box is in recovery/FEL mode (shorted test-point, recovery button, or AV jack switch). The app detects the low-level hardware signature (`VID: 0x1f3a, PID: 0xefe8`), reads chip registers and BROM versions, creates a safety backup of existing eMMC/NAND partitions to local storage, verifies firmware image compatibility (SlimboxTV, PhoenixSuit format), flashes bootloader and OS partitions, verifies write checksums, and issues a hardware reboot command.
- **Target Audience / Persona**: TV box enthusiasts, custom ROM developers (SlimboxTV, CoreELEC, Armbian), repair technicians unbricking TV boxes without needing a desktop PC.
- **Key Value**: Eliminates the need for a Windows PC or fragile driver installations (LiveSuit/PhoenixSuit USB drivers) by executing the flashing and backup pipeline directly from an Android mobile device over USB OTG.

---

### 2. User Experience & Visual Design

#### Key User Flows

1. **Hardware Connection & Discovery (Rule 1)**:
   - User plugs the OTG cable into the TV box while holding the recovery button (or shorting FEL pin).
   - The app's USB listener immediately detects the Allwinner device (`1F3A:EFE8`).
   - The status bar flips to "FEL Mode Connected" with chip identification (e.g., "Allwinner H616 - Rev C, BROM v1.2").

2. **FEL Driver & PhoenixSuit Handshake (Rule 2)**:
   - App transmits the 16-byte FEL protocol token (`AWUC` standard packet).
   - Reads hardware registers, executes DRAM initialization, and opens communication pipe for partition operations.
   - Live hex/log console shows command responses and handshake acknowledgments.

3. **Image Selection & Compatibility Check (Rule 3)**:
   - User browses and picks a SlimboxTV or PhoenixSuit `.img` file.
   - Flasher parses the image header, inspects partition tables (`bootloader`, `env`, `boot`, `system`, `vendor`, `recovery`), verifies SHA256 integrity, and checks eMMC capacity against target partition sizes.

4. **Pre-Flash Safety Backup**:
   - Before touching any partition, the user selects a backup folder via the system folder picker.
   - The app reads current device partitions (bootloader, dtb, recovery, vendor, system) block-by-block and streams them into a timestamped `.img` backup file.

5. **Flashing & Partition Writing (Rule 4)**:
   - User reviews flashing summary checklist and swipes a safety slider to start.
   - App flashes partitions sequentially with animated progress indicators (MB/s throughput, ETA, block write counter).
   - Verifies written blocks with MD5/CRC checksums.
   - Sends the Allwinner software reboot command (`FEL_EFEX_REBOOT` or fastboot continue) to restart the TV box into the newly installed SlimboxTV OS.

6. **Termux & Shell Command Center**:
   - Tab allowing power users to inspect raw shell commands, export automated flashing scripts (`flash_allwinner.sh`), or execute commands through the Termux intent bridge or root shell (`su`).

#### Visual Identity & Theme

- **Aesthetic Direction**: High-tech hardware diagnostics console ("Cyber Industrial" dark theme) with slate dark surfaces, neon cyan and phosphor emerald status indicators, and crisp monospace telemetry logs.
- **Color Palette & Mood**:
  - Background: Deep Obsidian Charcoal (`#0B0F14`)
  - Surface Containers: Dark Slate Slate (`#151C24`) and Elevated Card Surface (`#1C2631`)
  - Accent / Primary: Electric Cyan (`#00E5FF`) for connection states, action buttons, and active tabs
  - Success / Integrity: Phosphor Mint (`#00E676`) for backup verified, partition match, and successful flash
  - Warning / Flashing: Warning Amber (`#FFAB00`) for destructive write warnings and pre-flash checks
  - Error: Coral Crimson (`#FF5252`) for connection drops or signature mismatches
- **Typography & Hierarchy**:
  - Headers & Stat Counters: Bold geometric sans-serif for hardware specifications and progress percentages.
  - Telemetry & Logs: Clean monospace typography (`FontFamily.Monospace`) for memory offsets, USB hex packets, and terminal outputs.
- **Interactive Feedback & Motion**:
  - Live pulse animation on the USB connection badge.
  - Smooth animated linear and circular progress indicators during backup and write operations.
  - Haptic feedback and confirmation slider for irreversible flashing operations.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Direct Android USB Host API vs. Termux-Only CLI**
  - *Chosen Approach*: Implement a native Kotlin Allwinner FEL & PhoenixSuit USB protocol client using Android's `UsbManager` and `UsbDeviceConnection`, while simultaneously providing a companion Termux command generator and bridge.
  - *Why*: Direct USB Host allows the app to work out-of-the-box on any standard Android phone via USB OTG without requiring Termux setup, proot-distro, or root access, while the Termux bridge gives advanced developers command-line parity and customization.
  - *Alternatives Considered*: Termux-only would require complex user setup (installing termux, proot, debian, building sunxi-tools with libusb); Native-only would not satisfy the user's explicit request to utilize Termux and shell commands. Dual approach delivers the best of both worlds.

- **Decision 2: Image Parsing and Partition Handling**
  - *Chosen Approach*: Support both Allwinner PhoenixSuit image format (unpacking `sys_config.fex`, `bootloader.fex`, and partition images) and raw/sparse images typical of SlimboxTV.
  - *Why*: SlimboxTV releases are distributed either as complete PhoenixSuit burnable `.img` containers or sparse partition files. The parser automatically detects the container type.

- **Decision 3: Pre-Flash Full Backup via SAF**
  - *Chosen Approach*: Stream partition reads directly to a user-selected folder via Android DocumentFile URI, chunked in 64KB blocks.
  - *Why*: Android scoped storage limits arbitrary filesystem writes; Storage Access Framework allows users to save large multi-gigabyte backup images to internal storage or external SD cards safely.

---

### 4. Technical Architecture & Data Strategy

#### Architecture & Component Diagram

```
┌────────────────────────────────────────────────────────────────────────┐
│                        Jetpack Compose UI Layer                        │
│ ┌───────────────────┐ ┌───────────────────┐ ┌────────────────────────┐ │
│ │ Connection Wizard │ │ Firmware & Backup │ │ Flashing & Partition  │ │
│ │ (USB BROM Status) │ │ (SAF Picker, Ver) │ │ (Progress, Log Stream) │ │
│ └─────────┬─────────┘ └─────────┬─────────┘ └───────────┬────────────┘ │
│           │                     │                       │              │
│ ┌─────────┴─────────────────────┴───────────────────────┴────────────┐ │
│ │                  FlasherViewModel (State & Orchestration)          │ │
│ └─────────┬─────────────────────────────────────────────┬────────────┘ │
└───────────┼─────────────────────────────────────────────┼──────────────┘
            │                                             │
┌───────────▼──────────────────────────┐    ┌─────────────▼──────────────┐
│       AllwinnerFelUsbEngine          │    │    TermuxBridgeService     │
│ ┌──────────────────────────────────┐ │    │ ┌────────────────────────┐ │
│ │ UsbManager / UsbDeviceConnection │ │    │ │ Shell Command Runner   │ │
│ │ (VID: 0x1f3a, PID: 0xefe8)       │ │    │ │ Termux Intent Bridge   │ │
│ └──────────────────┬───────────────┘ │    │ │ Script Generator (.sh) │ │
│                    │                 │    │ └────────────────────────┘ │
│ ┌──────────────────▼───────────────┐ │    └────────────────────────────┘
│ │ Allwinner FEL Protocol Engine    │ │
│ │ - AWUC Handshake (16-byte magic) │ │
│ │ - Memory Read / Write (DRAM cfg) │ │
│ │ - PhoenixSuit Partition Burner   │ │
│ │ - Device Reset / FEL_REBOOT      │ │
│ └──────────────────┬───────────────┘ │
│                    │                 │
│ ┌──────────────────▼───────────────┐ │
│ │ Partition Backup & Verify Writer │ │
│ └──────────────────────────────────┘ │
└────────────────────┬─────────────────┘
                     │ (USB OTG Cable)
                     ▼
┌──────────────────────────────────────┐
│        Allwinner TV Box (eMMC)       │
│  H616 / H313 / H6 in FEL / BROM Mode │
└──────────────────────────────────────┘
```

#### Core Modules & State Models

- **`FelDeviceState`**: Tracks connection status (`DISCONNECTED`, `DEVICE_ATTACHED_NO_PERMISSION`, `FEL_CONNECTED`, `BROM_HANDSHAKED`, `FLASHING`, `BACKING_UP`, `SUCCESS`, `ERROR`), chip details (SoC model, BROM ID, DRAM size), USB endpoints.
- **`FirmwareImage`**: Holds parsed image metadata (container type, partition list, total size, sha256 checksum, compatibility flag).
- **`BackupJob`**: Manages backup destination URI, current partition being read, bytes written, and elapsed time.
- **`FlashingPipeline`**: Handles sequential execution: Connection Check -> FEL Handshake -> Compatibility Gate -> Partition Backup -> Partition Write -> Checksum Verify -> Reboot.
- **`TermuxBridge`**: Generates ready-to-run shell scripts (`phoenixsuit-termux.sh`, `sunxi-fel-flash.sh`), displays commands in terminal UI with one-tap copy/launch into Termux.

---

### Verification Plan

1. **USB Host Connectivity Check**: Verify USB intent filtering for Allwinner Vendor ID `0x1f3a` and Product ID `0xefe8` in `AndroidManifest.xml`.
2. **Protocol Engine Validation**: Test FEL packet generation (`AWUC` standard request token, read/write commands, status responses).
3. **Firmware Parser Verification**: Verify PhoenixSuit and SlimboxTV partition header extraction logic.
4. **Applet Compilation**: Run `compile_applet` to ensure full build success, zero lint errors, and compliance with Android 14/15/16 edge-to-edge guidelines.
