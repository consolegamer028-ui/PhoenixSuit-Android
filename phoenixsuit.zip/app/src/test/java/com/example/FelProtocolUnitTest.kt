package com.example

import com.example.fel.AllwinnerConstants
import com.example.fel.FelPacket
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.ByteBuffer
import java.nio.ByteOrder

class FelProtocolUnitTest {

    @Test
    fun testAwucPacketStructure() {
        val cmd = FelPacket.createAwucCommand(
            command = AllwinnerConstants.FEL_CMD_VERIFY_DEV,
            length = 0,
            tag = 0x1234
        )

        assertEquals(16, cmd.size)

        // Verify "AWUC" magic in first 4 bytes
        assertEquals('A'.code.toByte(), cmd[0])
        assertEquals('W'.code.toByte(), cmd[1])
        assertEquals('U'.code.toByte(), cmd[2])
        assertEquals('C'.code.toByte(), cmd[3])

        // Verify tag
        val buffer = ByteBuffer.wrap(cmd).order(ByteOrder.LITTLE_ENDIAN)
        buffer.position(4)
        val parsedTag = buffer.int
        assertEquals(0x1234, parsedTag)

        // Verify opcode at offset 14
        buffer.position(14)
        val parsedOpcode = buffer.short.toInt()
        assertEquals(AllwinnerConstants.FEL_CMD_VERIFY_DEV, parsedOpcode)
    }

    @Test
    fun testChipIdentification() {
        // Allwinner H616 BROM ID
        val h616 = AllwinnerConstants.identifyChip(0x00185100)
        assertEquals("Allwinner H616", h616.name)
        assertTrue(h616.architecture.contains("Cortex-A53"))

        // Allwinner H313 BROM ID
        val h313 = AllwinnerConstants.identifyChip(0x00182300)
        assertEquals("Allwinner H313", h313.name)

        // Allwinner H6 BROM ID
        val h6 = AllwinnerConstants.identifyChip(0x00168900)
        assertEquals("Allwinner H6", h6.name)
    }

    @Test
    fun testAwusResponseParsing() {
        // Construct valid AWUS response
        val buffer = ByteBuffer.allocate(13).order(ByteOrder.LITTLE_ENDIAN)
        buffer.put(AllwinnerConstants.FEL_MAGIC_AWUS)
        buffer.putInt(0x55aa) // tag
        buffer.putInt(0)      // residue
        buffer.put(0.toByte()) // status = 0 (success)

        val result = FelPacket.parseAwusResponse(buffer.array())
        assertTrue(result.success)
        assertEquals(0x55aa, result.tag)
        assertEquals(0, result.status)
    }
}
