package com.example

import android.app.Application
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.example.fel.AllwinnerConstants
import com.example.fel.FelPacket
import com.example.model.ConnectionStatus
import com.example.ui.FlashingStage
import com.example.viewmodel.FlasherViewModel
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PartitionAndHandshakeTest {

    private val application: Application = ApplicationProvider.getApplicationContext()

    // =========================================================================
    // 1. FEL HANDSHAKING TESTS
    // =========================================================================

    @Test
    fun testFelVerifyDevCommandCreation() {
        // AWUC standard 16-byte verify command
        val cmd = FelPacket.createAwucCommand(
            command = AllwinnerConstants.FEL_CMD_VERIFY_DEV,
            length = 0,
            tag = 0x1001
        )
        assertEquals(16, cmd.size)

        // Check magic "AWUC"
        assertEquals(0x41.toByte(), cmd[0]) // 'A'
        assertEquals(0x57.toByte(), cmd[1]) // 'W'
        assertEquals(0x55.toByte(), cmd[2]) // 'U'
        assertEquals(0x43.toByte(), cmd[3]) // 'C'

        // Check little-endian tag
        val buf = ByteBuffer.wrap(cmd).order(ByteOrder.LITTLE_ENDIAN)
        assertEquals(0x43555741, buf.int) // "AWUC" as little-endian int
        assertEquals(0x1001, buf.int)
        assertEquals(0, buf.int)          // length
        assertEquals(0.toShort(), buf.short) // flags
        assertEquals(AllwinnerConstants.FEL_CMD_VERIFY_DEV.toShort(), buf.short) // opcode
    }

    @Test
    fun testFelRebootCommandCreation() {
        val cmd = FelPacket.createAwucCommand(
            command = AllwinnerConstants.FEL_CMD_REBOOT,
            tag = 0x9999
        )
        assertEquals(16, cmd.size)
        val buf = ByteBuffer.wrap(cmd).order(ByteOrder.LITTLE_ENDIAN)
        buf.position(4)
        assertEquals(0x9999, buf.int)
        buf.position(14)
        assertEquals(AllwinnerConstants.FEL_CMD_REBOOT.toShort(), buf.short)
    }

    @Test
    fun testFel32ByteMemoryRequestCreation() {
        val req = FelPacket.createMemoryRequest(
            command = AllwinnerConstants.FEL_CMD_READ,
            address = 0x40000000L,
            length = 65536L,
            tag = 0x7777
        )
        assertEquals(32, req.size)
        val buf = ByteBuffer.wrap(req).order(ByteOrder.LITTLE_ENDIAN)
        buf.position(4)
        assertEquals(0x7777, buf.int)
        assertEquals(65536, buf.int)
        buf.position(16)
        assertEquals(0x40000000.toInt(), buf.int)
        assertEquals(65536, buf.int)
    }

    @Test
    fun testAwusResponseValidation() {
        // Valid AWUS token with status 0 (Success)
        val valid = ByteBuffer.allocate(13).order(ByteOrder.LITTLE_ENDIAN)
            .put(AllwinnerConstants.FEL_MAGIC_AWUS)
            .putInt(0x1001) // tag
            .putInt(0)      // residue
            .put(0.toByte()) // status = 0
            .array()

        val parsed = FelPacket.parseAwusResponse(valid)
        assertTrue("AWUS valid packet must return success = true", parsed.success)
        assertEquals(0x1001, parsed.tag)
        assertEquals(0, parsed.status)

        // Invalid token with bad magic
        val badMagic = byteArrayOf(0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C)
        val badResult = FelPacket.parseAwusResponse(badMagic)
        assertFalse("Bad magic must fail AWUS parsing", badResult.success)

        // Error status response (e.g. status = 1)
        val errorStatus = ByteBuffer.allocate(13).order(ByteOrder.LITTLE_ENDIAN)
            .put(AllwinnerConstants.FEL_MAGIC_AWUS)
            .putInt(0x2002)
            .putInt(0)
            .put(1.toByte()) // status != 0
            .array()
        val errorResult = FelPacket.parseAwusResponse(errorStatus)
        assertFalse("Non-zero status must return success = false", errorResult.success)
        assertEquals(1, errorResult.status)
    }

    @Test
    fun testBromVersionParsingAndAllwinnerChipMapping() {
        // Simulated Allwinner H616 BROM response
        val h616Buf = ByteBuffer.allocate(32).order(ByteOrder.LITTLE_ENDIAN)
            .putInt(0x00185100)
            .array()
        val h616Id = FelPacket.parseBromVersion(h616Buf)
        val h616Info = AllwinnerConstants.identifyChip(h616Id)
        assertEquals("Allwinner H616", h616Info.name)
        assertTrue(h616Info.popularBoxes.contains("Tanix TX6s"))

        // Simulated Allwinner H313 BROM response
        val h313Buf = ByteBuffer.allocate(32).order(ByteOrder.LITTLE_ENDIAN)
            .putInt(0x00182300)
            .array()
        val h313Id = FelPacket.parseBromVersion(h313Buf)
        val h313Info = AllwinnerConstants.identifyChip(h313Id)
        assertEquals("Allwinner H313", h313Info.name)
        assertTrue(h313Info.popularBoxes.contains("X96Q"))

        // Simulated Allwinner H6 BROM response
        val h6Buf = ByteBuffer.allocate(32).order(ByteOrder.LITTLE_ENDIAN)
            .putInt(0x00168900)
            .array()
        val h6Id = FelPacket.parseBromVersion(h6Buf)
        val h6Info = AllwinnerConstants.identifyChip(h6Id)
        assertEquals("Allwinner H6", h6Info.name)

        // Unknown future chip fallback
        val unknownInfo = AllwinnerConstants.identifyChip(0x00999900)
        assertTrue(unknownInfo.name.contains("Allwinner SoC"))
    }

    // =========================================================================
    // 2. PARTITION CREATING & BACKUP INTEGRITY TESTS
    // =========================================================================

    @Test
    fun testFirmwarePartitionCreationAndLayout() {
        val viewModel = FlasherViewModel(application)
        viewModel.loadSampleSlimboxTvFirmware("Allwinner H616")

        val fw = viewModel.firmwareDetails.value
        assertNotNull("FirmwareDetails must not be null", fw)
        assertEquals("Allwinner H616", fw!!.targetSoC)
        assertTrue(fw.isCompatibleWithConnectedChip)

        // Check required Allwinner boot & OS partitions
        val partitionNames = fw.partitions.map { it.name }
        assertTrue("Must include boot0 SPL", partitionNames.contains("boot0_bootloader"))
        assertTrue("Must include uboot", partitionNames.contains("uboot"))
        assertTrue("Must include device tree dtb", partitionNames.contains("dtb"))
        assertTrue("Must include kernel boot partition", partitionNames.contains("boot"))
        assertTrue("Must include vendor partition", partitionNames.contains("vendor"))
        assertTrue("Must include system OS partition", partitionNames.contains("system"))

        // Verify total size matches sum of individual partitions
        val calculatedSum = fw.partitions.sumOf { it.sizeBytes }
        assertEquals(calculatedSum, fw.fileSize)

        // Verify critical partitions are flagged
        val criticalPartitions = fw.partitions.filter { it.isCritical }.map { it.name }
        assertTrue(criticalPartitions.contains("boot0_bootloader"))
        assertTrue(criticalPartitions.contains("uboot"))
        assertTrue(criticalPartitions.contains("system"))
    }

    @Test
    fun testCustomImagePartitionParsing() {
        val viewModel = FlasherViewModel(application)
        val customSize = 2L * 1024 * 1024 * 1024 // 2 GB
        viewModel.setCustomFirmwareFile("slimbox_custom_h616.img", customSize)

        val fw = viewModel.firmwareDetails.value
        assertNotNull(fw)
        assertEquals("slimbox_custom_h616.img", fw!!.fileName)
        assertEquals(customSize, fw.fileSize)
        assertTrue(fw.partitions.any { it.name == "system" })
    }

    @Test
    fun testPreFlashBackupStreamingAndSha256Verification() = runTest {
        val outputStream = ByteArrayOutputStream()
        val md = MessageDigest.getInstance("SHA-256")

        // Simulate partition generation block-by-block
        val testPartitions = listOf(
            "boot0" to 64 * 1024,       // 64 KB
            "uboot" to 128 * 1024,      // 128 KB
            "boot" to 256 * 1024        // 256 KB
        )

        val totalExpected = testPartitions.sumOf { it.second }
        var bytesWritten = 0L
        val chunkSize = 64 * 1024
        val chunk = ByteArray(chunkSize)

        for ((partName, partSize) in testPartitions) {
            var written = 0
            while (written < partSize) {
                val toWrite = minOf(chunkSize, partSize - written)
                // Fill with deterministic partition pattern
                for (i in 0 until toWrite) {
                    chunk[i] = ((written + i) and 0xFF).toByte()
                }
                outputStream.write(chunk, 0, toWrite)
                md.update(chunk, 0, toWrite)
                written += toWrite
                bytesWritten += toWrite
            }
        }

        outputStream.flush()
        assertEquals(totalExpected.toLong(), bytesWritten)
        assertEquals(totalExpected, outputStream.size())

        val digest = md.digest().joinToString("") { "%02x".format(it) }
        assertTrue("Digest must be valid 64-character hex string", digest.length == 64)

        // Verify digest against the outputStream bytes
        val verifyMd = MessageDigest.getInstance("SHA-256")
        verifyMd.update(outputStream.toByteArray())
        val verifyDigest = verifyMd.digest().joinToString("") { "%02x".format(it) }
        assertEquals("Checksum of dumped backup must strictly match verification hash", digest, verifyDigest)
    }

    @Test
    fun testPhysicalUsbDisconnectedStrictNoFalseStates() {
        val viewModel = FlasherViewModel(application)

        // Must strictly start as DISCONNECTED
        assertEquals(ConnectionStatus.DISCONNECTED, viewModel.connectionStatus.value)
        assertEquals(null, viewModel.deviceInfo.value)
        assertFalse(viewModel.isSimulationMode.value)

        // Handshake attempt without physical USB must fail and NOT set BROM_HANDSHAKED
        viewModel.performFelHandshake()
        assertEquals(ConnectionStatus.DISCONNECTED, viewModel.connectionStatus.value)
        assertEquals(null, viewModel.deviceInfo.value)

        // Hardware probe must abort with No Hardware Detected
        viewModel.loadSampleSlimboxTvFirmware("Allwinner H616")
        val probeResult = viewModel.probeDeviceInfoAndVerifySoc()
        assertTrue("Probe check performed", probeResult.isChecked)
        assertFalse("Cannot match when disconnected", probeResult.isMatch)
        assertTrue("Must abort when no hardware is connected", probeResult.isAborted)
        assertEquals("No Hardware Detected", probeResult.connectedSoc)
        assertTrue(probeResult.detailedReport.contains("NO DEVICE DETECTED"))

        // Flashing pipeline attempt must immediately reject without hardware
        viewModel.startFlashingPipeline()
        assertFalse("Must not flash without USB hardware", viewModel.isFlashing.value)
        assertEquals(false, viewModel.flashSuccess.value)

        // Pre-flash backup attempt must reject without hardware
        viewModel.startPreFlashBackup()
        assertFalse("Must not run backup without USB hardware", viewModel.backupJob.value.isRunning)
    }

    @Test
    fun testFlasherViewModelLifecycleAndStages() {
        val viewModel = FlasherViewModel(application)
        viewModel.setSimulationMode(true)

        // Test handshake trigger in simulation mode
        viewModel.performFelHandshake()
        val info = viewModel.deviceInfo.value
        assertNotNull("DeviceInfo should be created after handshake", info)
        assertEquals("Allwinner H616", info!!.chipName)
        assertTrue(info.isReadyForFlashing)

        // Test setting backup destination
        val fakeUri = Uri.parse("content://com.android.externalstorage.documents/document/primary%3Abackup.img")
        viewModel.setBackupDestination(fakeUri, "primary:backup.img")
        assertEquals(fakeUri, viewModel.backupJob.value.destinationUri)
        assertEquals("primary:backup.img", viewModel.backupJob.value.destinationPathDisplay)

        // Verify script generation
        viewModel.generateTermuxScript()
        val script = viewModel.termuxScript.value
        assertTrue("Script must contain sunxi-fel check", script.contains("sunxi-fel version"))
        assertTrue("Script must contain eMMC dump command", script.contains("sunxi-fel -v dump"))
        assertTrue("Script must contain write command", script.contains("sunxi-fel -v -p write"))
        assertTrue("Script must contain reboot", script.contains("sunxi-fel reboot"))
    }

    @Test
    fun testSlimboxCatalogAndDownloader() = runTest {
        val releases = com.example.downloader.SlimboxCatalog.RELEASES
        assertTrue("Catalog must contain SlimboxTV releases", releases.isNotEmpty())

        val h616 = releases.find { it.targetSoc == "Allwinner H616" }
        assertNotNull("Catalog must contain H616 release", h616)
        assertEquals(64, h616!!.sha256.length)
        assertTrue(h616.downloadUrl.endsWith(".img"))
        assertTrue(h616.fileSizeBytes > 500L * 1024 * 1024)

        // Test downloader
        val downloader = com.example.downloader.SlimboxDownloader(application)
        var reportedProgress = 0f
        val result = downloader.downloadImage(h616) { _, _, _, prog ->
            reportedProgress = prog
        }

        assertTrue("Download must succeed", result is com.example.downloader.SlimboxDownloader.DownloadResult.Success)
        val success = result as com.example.downloader.SlimboxDownloader.DownloadResult.Success
        assertTrue(success.file.exists())
        assertEquals(64, success.sha256.length)
        assertTrue(success.bytes > 0)

        // Clean up test file
        success.file.delete()
    }

    // =========================================================================
    // 3. DEVICE INFO PROBE & SOC MATCH INSTANT ABORT TESTS
    // =========================================================================

    @Test
    fun testSocMatchVerificationSuccess() {
        val viewModel = FlasherViewModel(application)
        viewModel.setSimulationMode(true)
        // Load H616 firmware (connected chip defaults to H616 in simulation probe)
        viewModel.loadSampleSlimboxTvFirmware("Allwinner H616")

        val result = viewModel.probeDeviceInfoAndVerifySoc()
        assertTrue("Match check should be performed", result.isChecked)
        assertTrue("SoC match should be confirmed for H616 on H616", result.isMatch)
        assertFalse("Should not be aborted on match", result.isAborted)
        assertTrue(result.message.contains("MATCH CONFIRMED"))
        assertTrue(result.detailedReport.contains("BROM Hardware ID"))
        assertNotNull(viewModel.deviceInfo.value)
    }

    @Test
    fun testSocMismatchInstantAbort() {
        val viewModel = FlasherViewModel(application)
        viewModel.setSimulationMode(true)
        // Load H313 firmware, while connected chip is H616
        viewModel.loadSampleSlimboxTvFirmware("Allwinner H313")

        val result = viewModel.probeDeviceInfoAndVerifySoc()
        assertTrue("Match check should be performed", result.isChecked)
        assertFalse("SoC match must fail when connecting H616 to H313 image", result.isMatch)
        assertTrue("Instant abort must be triggered on mismatch", result.isAborted)
        assertTrue(result.message.contains("CRITICAL SoC MISMATCH"))
        assertEquals("Connection status must be set to ERROR on fatal mismatch", ConnectionStatus.ERROR, viewModel.connectionStatus.value)
        assertFalse("Flashing must be cancelled immediately", viewModel.isFlashing.value)
    }
}
