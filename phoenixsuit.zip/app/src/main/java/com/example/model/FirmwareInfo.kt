package com.example.model

data class FirmwarePartition(
    val name: String,
    val sizeBytes: Long,
    val description: String,
    val isCritical: Boolean = false,
    var flashProgress: Float = 0f,
    var isVerified: Boolean = false
)

data class FirmwareDetails(
    val fileName: String,
    val fileSize: Long,
    val targetSoC: String,
    val firmwareType: String, // "SlimboxTV (PhoenixSuit .img)", "Raw Sparse OS", etc.
    val partitions: List<FirmwarePartition>,
    val sha256Checksum: String,
    val isCompatibleWithConnectedChip: Boolean,
    val validationMessage: String
)
