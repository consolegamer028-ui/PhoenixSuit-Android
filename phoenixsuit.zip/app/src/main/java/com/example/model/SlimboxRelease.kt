package com.example.model

data class SlimboxRelease(
    val id: String,
    val title: String,
    val version: String,
    val androidVersion: String,
    val targetSoc: String,
    val popularBoxes: String,
    val fileSizeBytes: Long,
    val downloadUrl: String,
    val sha256: String,
    val features: List<String>,
    val releaseDate: String
)

data class SlimboxDownloadState(
    val isDownloading: Boolean = false,
    val activeRelease: SlimboxRelease? = null,
    val progress: Float = 0f,
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = 0L,
    val speedBytesPerSec: Long = 0L,
    val isCompleted: Boolean = false,
    val localFilePath: String? = null,
    val verifiedSha256: String? = null,
    val errorMessage: String? = null
)
