package com.example.model

enum class ConnectionStatus {
    DISCONNECTED,
    DEVICE_FOUND_PERMISSION_REQUIRED,
    FEL_CONNECTED,
    BROM_HANDSHAKED,
    BACKING_UP,
    FLASHING,
    VERIFYING,
    COMPLETED,
    ERROR
}

data class DiscoveredUsbDevice(
    val deviceName: String,
    val vendorId: Int,
    val productId: Int,
    val manufacturerName: String?,
    val productName: String?,
    val isAllwinnerFel: Boolean
)

data class AllwinnerDeviceInfo(
    val chipName: String,
    val chipArchitecture: String,
    val bromVersionHex: String,
    val dramStatus: String,
    val emmcCapacityMb: Long,
    val supportedFirmwares: String,
    val isReadyForFlashing: Boolean
)

data class SocMatchResult(
    val isChecked: Boolean,
    val isMatch: Boolean,
    val connectedSoc: String,
    val imageSoc: String,
    val message: String,
    val isAborted: Boolean,
    val detailedReport: String
)

