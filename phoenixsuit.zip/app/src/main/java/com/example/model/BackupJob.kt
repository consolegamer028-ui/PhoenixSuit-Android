package com.example.model

import android.net.Uri

data class BackupJob(
    val destinationUri: Uri?,
    val destinationPathDisplay: String,
    val fileName: String,
    val totalEstimatedBytes: Long,
    val bytesWritten: Long = 0L,
    val currentPartition: String = "Initializing",
    val speedBytesPerSec: Long = 0L,
    val isRunning: Boolean = false,
    val isCompleted: Boolean = false,
    val isVerified: Boolean = false,
    val verificationDigest: String = "",
    val errorMessage: String? = null
) {
    val progress: Float
        get() = if (totalEstimatedBytes > 0) (bytesWritten.toFloat() / totalEstimatedBytes).coerceIn(0f, 1f) else 0f
}

data class LogEntry(
    val timestamp: String,
    val level: LogLevel,
    val message: String
)

enum class LogLevel {
    INFO,
    SUCCESS,
    WARN,
    ERROR,
    HEX
}
