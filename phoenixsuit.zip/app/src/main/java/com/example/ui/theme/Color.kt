package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyber Industrial Hardware Flasher Palette
val CyberCyan = Color(0xFF00E5FF)
val CyberCyanDim = Color(0xFF00B0FF)
val PhosphorMint = Color(0xFF00E676)
val WarningAmber = Color(0xFFFFAB00)
val DangerCoral = Color(0xFFFF5252)

val DarkBackground = Color(0xFF0B0F14)
val DarkSurface = Color(0xFF131A22)
val DarkSurfaceVariant = Color(0xFF1B2430)
val DarkSurfaceHighlight = Color(0xFF243040)
val DarkBorder = Color(0xFF2D3C4F)

val TerminalBackground = Color(0xFF070A0E)
val TerminalTextGreen = Color(0xFF69F0AE)
val TerminalTextCyan = Color(0xFF80D8FF)
val TerminalTextMuted = Color(0xFF90A4AE)

val TextPrimary = Color(0xFFF0F4F8)
val TextSecondary = Color(0xFF90A4AE)
val TextTertiary = Color(0xFF607D8B)
