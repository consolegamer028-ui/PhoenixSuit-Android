package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectionStatus
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DangerCoral
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.PhosphorMint
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.FlasherViewModel

@Composable
fun FlashingTab(
    viewModel: FlasherViewModel,
    modifier: Modifier = Modifier
) {
    val connectionStatus by viewModel.connectionStatus.collectAsState()
    val isFlashing by viewModel.isFlashing.collectAsState()
    val flashProgress by viewModel.flashProgress.collectAsState()
    val currentPartition by viewModel.currentPartitionName.collectAsState()
    val currentSpeedBps by viewModel.currentSpeedBps.collectAsState()
    val flashSuccess by viewModel.flashSuccess.collectAsState()
    val backupJob by viewModel.backupJob.collectAsState()
    val firmwareDetails by viewModel.firmwareDetails.collectAsState()
    val deviceInfo by viewModel.deviceInfo.collectAsState()
    val socMatchResult by viewModel.socMatchResult.collectAsState()

    // Safety checks
    val isConnected = connectionStatus == ConnectionStatus.BROM_HANDSHAKED ||
            connectionStatus == ConnectionStatus.FLASHING ||
            connectionStatus == ConnectionStatus.VERIFYING ||
            connectionStatus == ConnectionStatus.COMPLETED
    val hasFirmware = firmwareDetails != null && firmwareDetails!!.isCompatibleWithConnectedChip
    val hasBackup = backupJob.isVerified
    val isSocAborted = socMatchResult?.isAborted == true

    val isReadyToFlash = isConnected && hasFirmware && hasBackup && !isFlashing && !isSocAborted

    val currentStage = when {
        flashSuccess == true -> FlashingStage.COMPLETED
        connectionStatus == ConnectionStatus.VERIFYING -> FlashingStage.VERIFYING
        isFlashing -> FlashingStage.WRITING_PARTITIONS
        backupJob.isRunning -> FlashingStage.BACKING_UP
        hasBackup -> FlashingStage.WRITING_PARTITIONS
        else -> FlashingStage.INITIALIZING
    }

    val overallProgress = when {
        flashSuccess == true -> 1f
        connectionStatus == ConnectionStatus.VERIFYING -> 0.85f + 0.15f * flashProgress
        isFlashing -> 0.40f + 0.45f * flashProgress
        backupJob.isRunning -> 0.10f + 0.30f * backupJob.progress
        hasBackup -> 0.40f
        isConnected -> 0.10f
        else -> 0f
    }

    val stageProgress = when {
        flashSuccess == true -> 1f
        connectionStatus == ConnectionStatus.VERIFYING -> 1f
        isFlashing -> flashProgress
        backupJob.isRunning -> backupJob.progress
        else -> 0f
    }

    val stageDetails = when {
        flashSuccess == true -> "All partitions written & verified! Ready to reboot."
        connectionStatus == ConnectionStatus.VERIFYING -> "Verifying partition block checksums (SHA-256)..."
        isFlashing -> "Writing to eMMC: partition '$currentPartition'"
        backupJob.isRunning -> "Backing up eMMC: partition '${backupJob.currentPartition}'"
        isReadyToFlash -> "Pre-flight checks verified. Ready to flash."
        !hasBackup -> "Pre-flash backup required before writing partitions."
        else -> "Connect TV Box in FEL mode to begin."
    }

    val activeSpeed = if (isFlashing) currentSpeedBps else if (backupJob.isRunning) backupJob.speedBytesPerSec else 0L

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Multi-Stage Visual Progress Tracker Component
        MultiStageProgressTracker(
            currentStage = currentStage,
            overallProgress = overallProgress,
            stageProgress = stageProgress,
            stageDetails = stageDetails,
            transferSpeedBps = activeSpeed,
            isError = connectionStatus == ConnectionStatus.ERROR,
            errorMessage = backupJob.errorMessage
        )
        // SUCCESS COMPLETION BANNER & REBOOT CONTROL
        if (flashSuccess == true) {
            CyberCard(
                borderColor = PhosphorMint,
                backgroundColor = PhosphorMint.copy(alpha = 0.08f)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = PhosphorMint,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "FLASHING & VERIFICATION COMPLETE!",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = PhosphorMint
                        )
                        Text(
                            text = "SlimboxTV OS has been burned to TV box eMMC.",
                            fontSize = 12.sp,
                            color = TextPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = PhosphorMint.copy(alpha = 0.3f))
                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { viewModel.rebootTvBox() },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("reboot_device_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = PhosphorMint, contentColor = Color(0xFF070A0E)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Reboot TV Box", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    OutlinedButton(
                        onClick = { viewModel.setSelectedTab(0) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Status / Diagnostics", fontSize = 12.sp, color = CyberCyan)
                    }
                }
            }
        }

        // ACTIVE FLASHING PROGRESS CARD
        if (isFlashing || connectionStatus == ConnectionStatus.VERIFYING) {
            CyberCard(borderColor = CyberCyan) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            progress = { flashProgress },
                            modifier = Modifier.size(24.dp),
                            color = CyberCyan,
                            strokeWidth = 3.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (connectionStatus == ConnectionStatus.VERIFYING) "VERIFYING INTEGRITY..." else "WRITING TO eMMC...",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyberCyan,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "Partition: $currentPartition",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Text(
                        text = "${(flashProgress * 100).toInt()}%",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = CyberCyan
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                LinearProgressIndicator(
                    progress = { flashProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = CyberCyan,
                    trackColor = DarkSurfaceHighlight
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val speedMb = currentSpeedBps / (1024.0 * 1024.0)
                    MetricBox(
                        title = "Write Speed",
                        value = String.format("%.1f", speedMb),
                        unit = "MB/s",
                        icon = Icons.Default.Speed,
                        accentColor = PhosphorMint,
                        modifier = Modifier.weight(1f)
                    )
                    MetricBox(
                        title = "Target SoC",
                        value = deviceInfo?.chipName?.replace("Allwinner ", "") ?: "H616",
                        icon = Icons.Default.Tv,
                        accentColor = CyberCyan,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // PRE-FLIGHT SAFETY GATES CHECKLIST (Mandatory rule check)
        CyberCard {
            Text(
                text = "PRE-FLIGHT HARDWARE SAFETY CHECKLIST",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            SafetyCheckItem(
                title = "Allwinner FEL Mode Active (AWUC Driver)",
                passed = isConnected,
                details = if (isConnected) "Device Handshaked (BROM v1.2 OK)" else "TV Box not connected in FEL mode",
                onFixAction = { viewModel.performFelHandshake() },
                actionLabel = "Handshake"
            )

            HorizontalDivider(color = DarkBorder, modifier = Modifier.padding(vertical = 8.dp))

            SafetyCheckItem(
                title = "Firmware Image Validation",
                passed = hasFirmware,
                details = if (hasFirmware) "${firmwareDetails?.fileName} (Compatible)" else "No image loaded",
                onFixAction = { viewModel.setSelectedTab(1) },
                actionLabel = "Choose"
            )

            HorizontalDivider(color = DarkBorder, modifier = Modifier.padding(vertical = 8.dp))

            SafetyCheckItem(
                title = "Pre-Flashing eMMC Backup (Rule 4)",
                passed = hasBackup,
                details = if (hasBackup) "Verified SHA-256 Checksum OK" else "Mandatory backup not created yet",
                onFixAction = { viewModel.setSelectedTab(1) },
                actionLabel = "Create Backup"
            )

            HorizontalDivider(color = DarkBorder, modifier = Modifier.padding(vertical = 8.dp))

            SafetyCheckItem(
                title = "SoC Hardware Match (Anti-Brick Guard)",
                passed = socMatchResult != null && !socMatchResult!!.isAborted,
                details = when {
                    socMatchResult == null -> "Not verified yet — Tap to probe connected SoC"
                    socMatchResult!!.isAborted -> "ABORTED: Connected '${socMatchResult!!.connectedSoc}' != Target '${socMatchResult!!.imageSoc}'"
                    else -> "MATCH CONFIRMED: ${socMatchResult!!.connectedSoc}"
                },
                onFixAction = { viewModel.probeDeviceInfoAndVerifySoc() },
                actionLabel = "Verify SoC"
            )

            HorizontalDivider(color = DarkBorder, modifier = Modifier.padding(vertical = 8.dp))

            SafetyCheckItem(
                title = "Power & USB Stability",
                passed = true,
                details = "OTG VBUS link stable. Do not disconnect during write.",
                onFixAction = null,
                actionLabel = null
            )
        }

        // SWIPE-TO-FLASH SLIDER (Accident Protection)
        CyberCard(borderColor = if (isSocAborted) DangerCoral else if (isReadyToFlash) WarningAmber else DarkBorder) {
            Text(
                text = "START PHOENIXSUIT OS BURNING",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isReadyToFlash) WarningAmber else TextSecondary,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Flashing will write the new bootloader, kernel, system, and vendor partitions into the TV box internal flash memory.",
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            SwipeToConfirmButton(
                text = ">>> SWIPE TO FLASH SLIMBOXTV >>>",
                enabled = isReadyToFlash,
                onConfirmed = {
                    viewModel.startFlashingPipeline()
                }
            )

            if (!isReadyToFlash && !isFlashing) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (!hasBackup) "Safety Lock: Complete Pre-Flashing Backup first!" else "Safety Lock: Complete all checks above.",
                        fontSize = 11.sp,
                        color = WarningAmber
                    )
                }
            }
        }

        // Partition Status Monitor
        if (firmwareDetails != null) {
            CyberCard {
                Text(
                    text = "PARTITION WRITE QUEUE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                firmwareDetails!!.partitions.forEach { part ->
                    val isCurrent = isFlashing && currentPartition == part.name
                    val isDone = flashSuccess == true || (isFlashing && flashProgress > 0.5f && part.name == "boot0")

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isCurrent) DarkSurfaceHighlight else DarkSurfaceVariant)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = when {
                                    isDone -> Icons.Default.Check
                                    isCurrent -> Icons.Default.FlashOn
                                    else -> Icons.Default.Storage
                                },
                                contentDescription = null,
                                tint = when {
                                    isDone -> PhosphorMint
                                    isCurrent -> CyberCyan
                                    else -> TextTertiary
                                },
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = part.name,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (isCurrent) CyberCyan else TextPrimary,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal
                            )
                        }

                        Text(
                            text = when {
                                isDone -> "WRITTEN"
                                isCurrent -> "WRITING..."
                                else -> "QUEUED"
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = when {
                                isDone -> PhosphorMint
                                isCurrent -> CyberCyan
                                else -> TextTertiary
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SafetyCheckItem(
    title: String,
    passed: Boolean,
    details: String,
    onFixAction: (() -> Unit)?,
    actionLabel: String?
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(if (passed) PhosphorMint.copy(alpha = 0.2f) else DangerCoral.copy(alpha = 0.2f))
                    .border(1.dp, if (passed) PhosphorMint else DangerCoral, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (passed) Icons.Default.Check else Icons.Default.Close,
                    contentDescription = null,
                    tint = if (passed) PhosphorMint else DangerCoral,
                    modifier = Modifier.size(12.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text(text = details, fontSize = 11.sp, color = TextSecondary)
            }
        }

        if (!passed && onFixAction != null && actionLabel != null) {
            OutlinedButton(
                onClick = onFixAction,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Text(actionLabel, fontSize = 11.sp, color = CyberCyan)
            }
        }
    }
}
