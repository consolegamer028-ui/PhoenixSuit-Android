package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.graphics.Brush
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectionStatus
import com.example.model.LogEntry
import com.example.model.LogLevel
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DangerCoral
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.PhosphorMint
import com.example.ui.theme.TerminalBackground
import com.example.ui.theme.TerminalTextCyan
import com.example.ui.theme.TerminalTextGreen
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber
import kotlin.math.roundToInt

@Composable
fun CyberCard(
    modifier: Modifier = Modifier,
    borderColor: Color = DarkBorder,
    backgroundColor: Color = DarkSurface,
    content: @Composable () -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, borderColor, RoundedCornerShape(12.dp)),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            content()
        }
    }
}

@Composable
fun StatusPill(status: ConnectionStatus) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alphaPulse by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    val (color, text, icon) = when (status) {
        ConnectionStatus.DISCONNECTED -> Triple(DangerCoral, "NO USB LINK", Icons.Default.Usb)
        ConnectionStatus.DEVICE_FOUND_PERMISSION_REQUIRED -> Triple(WarningAmber, "PERM NEEDED", Icons.Default.Warning)
        ConnectionStatus.FEL_CONNECTED -> Triple(CyberCyan, "FEL DETECTED", Icons.Default.Bolt)
        ConnectionStatus.BROM_HANDSHAKED -> Triple(PhosphorMint, "FEL READY", Icons.Default.CheckCircle)
        ConnectionStatus.BACKING_UP -> Triple(CyberCyan, "BACKING UP", Icons.Default.Bolt)
        ConnectionStatus.FLASHING -> Triple(WarningAmber, "FLASHING eMMC", Icons.Default.Bolt)
        ConnectionStatus.VERIFYING -> Triple(CyberCyan, "VERIFYING", Icons.Default.CheckCircle)
        ConnectionStatus.COMPLETED -> Triple(PhosphorMint, "FLASH SUCCESS", Icons.Default.CheckCircle)
        ConnectionStatus.ERROR -> Triple(DangerCoral, "FEL FAULT", Icons.Default.Error)
    }

    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(
                    if (status == ConnectionStatus.FLASHING || status == ConnectionStatus.BACKING_UP)
                        color.copy(alpha = alphaPulse)
                    else color
                )
        )
        Spacer(modifier = Modifier.width(6.dp))
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = text,
            color = color,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun MetricBox(
    title: String,
    value: String,
    unit: String = "",
    icon: ImageVector,
    accentColor: Color = CyberCyan,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .border(1.dp, DarkBorder, RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title.uppercase(),
                    fontSize = 10.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.5.sp
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(14.dp)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = value,
                    fontSize = 17.sp,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                if (unit.isNotEmpty()) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = unit,
                        fontSize = 11.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(bottom = 1.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun TerminalConsole(
    logEntries: List<LogEntry>,
    onClear: () -> Unit,
    modifier: Modifier = Modifier
) {
    val clipboardManager: ClipboardManager = LocalClipboardManager.current
    val listState = rememberLazyListState()

    LaunchedEffect(logEntries.size) {
        if (logEntries.isNotEmpty()) {
            listState.animateScrollToItem(logEntries.size - 1)
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, DarkBorder, RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(containerColor = TerminalBackground),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column {
            // Header bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurfaceVariant)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "FEL TELEMETRY LOGS (${logEntries.size})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        letterSpacing = 0.5.sp
                    )
                }

                Row {
                    IconButton(
                        onClick = {
                            val text = logEntries.joinToString("\n") { "[${it.timestamp}] ${it.message}" }
                            clipboardManager.setText(AnnotatedString(text))
                        },
                        modifier = Modifier.size(28.dp).testTag("copy_logs_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy logs",
                            tint = TextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    IconButton(
                        onClick = onClear,
                        modifier = Modifier.size(28.dp).testTag("clear_logs_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Clear logs",
                            tint = TextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            // Console output
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 100.dp, max = 160.dp)
                    .padding(8.dp)
            ) {
                if (logEntries.isEmpty()) {
                    item {
                        Text(
                            text = "Waiting for FEL events... Connect TV box via USB OTG.",
                            fontSize = 11.sp,
                            color = TerminalTextMuted,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                } else {
                    items(logEntries) { entry ->
                        val color = when (entry.level) {
                            LogLevel.SUCCESS -> TerminalTextGreen
                            LogLevel.ERROR -> DangerCoral
                            LogLevel.WARN -> WarningAmber
                            LogLevel.HEX -> TerminalTextCyan
                            LogLevel.INFO -> TextSecondary
                        }

                        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp)) {
                            Text(
                                text = entry.timestamp,
                                fontSize = 10.sp,
                                color = TerminalTextMuted,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.width(55.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = entry.message,
                                fontSize = 11.sp,
                                color = color,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SwipeToConfirmButton(
    text: String,
    enabled: Boolean,
    onConfirmed: () -> Unit,
    modifier: Modifier = Modifier
) {
    var offsetX by remember { mutableFloatStateOf(0f) }
    val maxDragWidth = 240.dp
    val density = androidx.compose.ui.platform.LocalDensity.current
    val maxPx = with(density) { maxDragWidth.toPx() }

    val trackColor = if (enabled) DarkSurfaceHighlight else DarkSurfaceVariant
    val thumbColor by animateColorAsState(
        targetValue = if (offsetX >= maxPx * 0.85f) PhosphorMint else CyberCyan,
        label = "thumb"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(RoundedCornerShape(27.dp))
            .background(trackColor)
            .border(1.dp, if (enabled) CyberCyan.copy(alpha = 0.5f) else DarkBorder, RoundedCornerShape(27.dp))
            .testTag("swipe_flash_slider"),
        contentAlignment = Alignment.CenterStart
    ) {
        // Background text
        Text(
            text = if (enabled) text else "Complete Pre-Flash Safety Gate First",
            color = if (enabled) TextSecondary else TextTertiary,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.align(Alignment.Center)
        )

        // Draggable thumb
        Box(
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), 0) }
                .size(54.dp)
                .clip(CircleShape)
                .background(if (enabled) thumbColor else TextTertiary)
                .draggable(
                    enabled = enabled,
                    orientation = Orientation.Horizontal,
                    state = rememberDraggableState { delta ->
                        val newOffset = (offsetX + delta).coerceIn(0f, maxPx)
                        offsetX = newOffset
                        if (newOffset >= maxPx * 0.90f) {
                            offsetX = 0f
                            onConfirmed()
                        }
                    },
                    onDragStopped = {
                        if (offsetX < maxPx * 0.90f) {
                            offsetX = 0f
                        }
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.KeyboardArrowRight,
                contentDescription = "Swipe arrow",
                tint = DarkBackground,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

/**
 * Multi-stage flashing and verification process tracking.
 */
enum class FlashingStage(
    val title: String,
    val shortLabel: String,
    val icon: ImageVector,
    val stepIndex: Int
) {
    INITIALIZING("FEL Link", "Link", Icons.Default.Usb, 0),
    BACKING_UP("Backing up...", "Backup", Icons.Default.Backup, 1),
    WRITING_PARTITIONS("Writing partitions...", "Flashing", Icons.Default.FlashOn, 2),
    VERIFYING("Verifying...", "Verify", Icons.Default.Verified, 3),
    COMPLETED("Completed", "Reboot", Icons.Default.RestartAlt, 4)
}

@Composable
fun MultiStageProgressTracker(
    currentStage: FlashingStage,
    overallProgress: Float,
    stageProgress: Float,
    stageDetails: String,
    transferSpeedBps: Long,
    etaSeconds: Int = 0,
    isError: Boolean = false,
    errorMessage: String? = null,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "stage_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isError) DangerCoral else if (currentStage == FlashingStage.COMPLETED) PhosphorMint else CyberCyan,
                RoundedCornerShape(14.dp)
            ),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header with current stage name and overall percentage
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "MULTI-STAGE PIPELINE TRACKER",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (isError) "Process Interrupted" else currentStage.title,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isError) DangerCoral else if (currentStage == FlashingStage.COMPLETED) PhosphorMint else CyberCyan
                    )
                }

                // Overall progress percentage pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            (if (isError) DangerCoral else if (currentStage == FlashingStage.COMPLETED) PhosphorMint else CyberCyan)
                                .copy(alpha = 0.15f)
                        )
                        .border(
                            1.dp,
                            if (isError) DangerCoral else if (currentStage == FlashingStage.COMPLETED) PhosphorMint else CyberCyan,
                            RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "${(overallProgress.coerceIn(0f, 1f) * 100).toInt()}%",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = if (isError) DangerCoral else if (currentStage == FlashingStage.COMPLETED) PhosphorMint else CyberCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Visual 5-Stage Stepper Track
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val stages = FlashingStage.values()
                stages.forEachIndexed { index, stage ->
                    val isPast = stage.stepIndex < currentStage.stepIndex || currentStage == FlashingStage.COMPLETED
                    val isCurrent = stage.stepIndex == currentStage.stepIndex && currentStage != FlashingStage.COMPLETED
                    val isPending = stage.stepIndex > currentStage.stepIndex && currentStage != FlashingStage.COMPLETED

                    // Stage Node
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        isError && isCurrent -> DangerCoral
                                        isPast -> PhosphorMint
                                        isCurrent -> CyberCyan.copy(alpha = pulseAlpha)
                                        else -> DarkSurfaceVariant
                                    }
                                )
                                .border(
                                    1.dp,
                                    when {
                                        isError && isCurrent -> DangerCoral
                                        isPast -> PhosphorMint
                                        isCurrent -> CyberCyan
                                        else -> DarkBorder
                                    },
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            when {
                                isError && isCurrent -> Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = null,
                                    tint = DarkBackground,
                                    modifier = Modifier.size(16.dp)
                                )
                                isPast -> Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = DarkBackground,
                                    modifier = Modifier.size(16.dp)
                                )
                                isCurrent -> Icon(
                                    imageVector = stage.icon,
                                    contentDescription = null,
                                    tint = DarkBackground,
                                    modifier = Modifier.size(16.dp)
                                )
                                else -> Text(
                                    text = "${stage.stepIndex + 1}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextTertiary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = stage.shortLabel,
                            fontSize = 10.sp,
                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                            color = when {
                                isError && isCurrent -> DangerCoral
                                isPast -> PhosphorMint
                                isCurrent -> CyberCyan
                                else -> TextSecondary
                            },
                            maxLines = 1
                        )
                    }

                    // Connecting Line between stage nodes
                    if (index < stages.size - 1) {
                        val nextPast = currentStage.stepIndex > index || currentStage == FlashingStage.COMPLETED
                        val activeLine = currentStage.stepIndex == index && !isError

                        Box(
                            modifier = Modifier
                                .weight(0.7f)
                                .height(3.dp)
                                .padding(bottom = 14.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(
                                    when {
                                        nextPast -> PhosphorMint
                                        activeLine -> CyberCyan.copy(alpha = pulseAlpha)
                                        else -> DarkBorder
                                    }
                                )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main Overall Progress Bar
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Overall Flashing & Verification",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                    Text(
                        text = "${(overallProgress.coerceIn(0f, 1f) * 100).toInt()}%",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { overallProgress.coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp)),
                    color = if (isError) DangerCoral else if (currentStage == FlashingStage.COMPLETED) PhosphorMint else CyberCyan,
                    trackColor = DarkSurfaceHighlight
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Stage Sub-Progress Bar with real-time feedback
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (isError) (errorMessage ?: "Error during operation") else stageDetails,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isError) DangerCoral else CyberCyan,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${(stageProgress.coerceIn(0f, 1f) * 100).toInt()}%",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextSecondary
                    )
                }
                Spacer(modifier = Modifier.height(5.dp))
                LinearProgressIndicator(
                    progress = { stageProgress.coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = PhosphorMint,
                    trackColor = DarkSurfaceHighlight
                )
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = DarkBorder)
            Spacer(modifier = Modifier.height(12.dp))

            // Real-Time Telemetry Metrics Footer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Live Speed
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = null,
                        tint = PhosphorMint,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text("THROUGHPUT", fontSize = 9.sp, color = TextTertiary, fontWeight = FontWeight.Bold)
                        val speedMb = transferSpeedBps / (1024.0 * 1024.0)
                        Text(
                            text = if (speedMb > 0) String.format("%.1f MB/s", speedMb) else "Idle",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = PhosphorMint
                        )
                    }
                }

                // Estimated Time Remaining (ETA)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.HourglassTop,
                        contentDescription = null,
                        tint = WarningAmber,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text("ESTIMATED TIME", fontSize = 9.sp, color = TextTertiary, fontWeight = FontWeight.Bold)
                        Text(
                            text = when {
                                currentStage == FlashingStage.COMPLETED -> "Done"
                                etaSeconds > 0 -> String.format("%02d:%02d", etaSeconds / 60, etaSeconds % 60)
                                transferSpeedBps > 0 -> "~00:35"
                                else -> "--:--"
                            },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = WarningAmber
                        )
                    }
                }

                // Status Badge
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(DarkSurfaceVariant)
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(
                                if (isError) DangerCoral
                                else if (currentStage == FlashingStage.COMPLETED) PhosphorMint
                                else CyberCyan
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isError) "FAIL" else if (currentStage == FlashingStage.COMPLETED) "VERIFIED" else "ACTIVE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
            }
        }
    }
}
