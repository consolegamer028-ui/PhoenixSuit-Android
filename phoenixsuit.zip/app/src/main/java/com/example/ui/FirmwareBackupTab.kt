package com.example.ui

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import com.example.downloader.DownloadedImgFile
import com.example.model.SlimboxRelease
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DangerCoral
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.PhosphorMint
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.FlasherViewModel

@Composable
fun FirmwareBackupTab(
    viewModel: FlasherViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val firmwareDetails by viewModel.firmwareDetails.collectAsState()
    val backupJob by viewModel.backupJob.collectAsState()
    val deviceInfo by viewModel.deviceInfo.collectAsState()
    val downloadState by viewModel.downloadState.collectAsState()
    val socFilter by viewModel.socFilter.collectAsState()
    val availableReleases = viewModel.availableReleases
    val scannedDownloadImages by viewModel.scannedDownloadImages.collectAsState()

    // File Picker for custom ROM (.img)
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val (name, size) = getFileInfo(context, uri)
            viewModel.setCustomFirmwareFile(name, size)
        }
    }

    // SAF Document Creator for saving pre-flash backup image
    val backupDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.setBackupDestination(uri, uri.lastPathSegment ?: "Backup Image")
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // PRE-FLASHING BACKUP SECTION (Prominent User-Facing Safety Gate)
        CyberCard(
            borderColor = if (backupJob.isVerified) PhosphorMint else WarningAmber
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (backupJob.isVerified) Icons.Default.VerifiedUser else Icons.Default.Backup,
                        contentDescription = null,
                        tint = if (backupJob.isVerified) PhosphorMint else WarningAmber,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PRE-FLASHING BACKUP (MANDATORY)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (backupJob.isVerified) PhosphorMint else WarningAmber,
                        letterSpacing = 0.5.sp
                    )
                }

                if (backupJob.isVerified) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(PhosphorMint.copy(alpha = 0.15f))
                            .border(1.dp, PhosphorMint, RoundedCornerShape(12.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("BACKUP VERIFIED", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = PhosphorMint)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Before overwriting the TV box eMMC, create a complete raw backup image (.img) of all existing partitions. You can restore this if any flashing error occurs.",
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Destination selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSurfaceVariant)
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Storage Destination", fontSize = 10.sp, color = TextTertiary)
                    Text(
                        text = backupJob.destinationPathDisplay,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextPrimary,
                        maxLines = 1
                    )
                }
                OutlinedButton(
                    onClick = { backupDocLauncher.launch(backupJob.fileName) },
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("choose_backup_folder_btn")
                ) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(14.dp), tint = CyberCyan)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Select File", fontSize = 11.sp, color = CyberCyan)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Backup execution progress
            if (backupJob.isRunning) {
                MultiStageProgressTracker(
                    currentStage = FlashingStage.BACKING_UP,
                    overallProgress = 0.10f + 0.30f * backupJob.progress,
                    stageProgress = backupJob.progress,
                    stageDetails = "Dumping partition '${backupJob.currentPartition}'",
                    transferSpeedBps = backupJob.speedBytesPerSec
                )
                Spacer(modifier = Modifier.height(12.dp))
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Dumping: ${backupJob.currentPartition}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = CyberCyan
                        )
                        Text(
                            text = "${(backupJob.progress * 100).toInt()}%",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = CyberCyan
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { backupJob.progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = CyberCyan,
                        trackColor = DarkSurfaceHighlight
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${backupJob.bytesWritten / (1024 * 1024)} MB / ${backupJob.totalEstimatedBytes / (1024 * 1024)} MB",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextSecondary
                        )
                        val speedMb = backupJob.speedBytesPerSec / (1024.0 * 1024.0)
                        Text(
                            text = String.format("%.1f MB/s", speedMb),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = PhosphorMint
                        )
                    }
                }
            } else if (backupJob.isVerified) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(PhosphorMint.copy(alpha = 0.08f))
                        .border(1.dp, PhosphorMint.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PhosphorMint, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Integrity Verified via SHA-256 Checksum", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PhosphorMint)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = backupJob.verificationDigest,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextSecondary,
                        lineHeight = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = { viewModel.startPreFlashBackup() },
                enabled = !backupJob.isRunning,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("start_backup_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (backupJob.isVerified) DarkSurfaceHighlight else WarningAmber,
                    contentColor = if (backupJob.isVerified) TextPrimary else Color(0xFF070A0E)
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Backup,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (backupJob.isVerified) "Re-Dump Backup Image" else "Create & Verify Pre-Flash Backup",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }

        // BUILT-IN SLIMBOXTV DOWNLOAD CENTER
        CyberCard(borderColor = CyberCyan) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudDownload, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "BUILT-IN SLIMBOXTV DOWNLOAD CENTER",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyan,
                        letterSpacing = 0.5.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(CyberCyan.copy(alpha = 0.15f))
                        .border(1.dp, CyberCyan.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text("ONLINE CATALOG", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = CyberCyan)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Download verified official SlimboxTV PhoenixSuit .img firmware images for Allwinner ARM TV boxes directly to your device and auto-load them into the flasher.",
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Official Website Link & Chip portals
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSurfaceVariant)
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Language, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Official Portal: slimboxtv.ru", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                }

                OutlinedButton(
                    onClick = { viewModel.openSlimboxWebsite("https://slimboxtv.ru/") },
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("open_slimboxtv_ru_btn")
                ) {
                    Text("Visit Website", fontSize = 11.sp, color = CyberCyan)
                }
            }

            // Active in-progress download card
            if (downloadState.isDownloading || downloadState.isCompleted) {
                Spacer(modifier = Modifier.height(12.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (downloadState.isCompleted) PhosphorMint.copy(alpha = 0.08f) else DarkSurfaceHighlight)
                        .border(1.dp, if (downloadState.isCompleted) PhosphorMint else CyberCyan, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (downloadState.isCompleted) "Download & Verification Complete!" else "Downloading ${downloadState.activeRelease?.title ?: "SlimboxTV"}...",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (downloadState.isCompleted) PhosphorMint else CyberCyan
                        )
                        Text(
                            text = "${(downloadState.progress * 100).toInt()}%",
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (downloadState.isCompleted) PhosphorMint else CyberCyan
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { downloadState.progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (downloadState.isCompleted) PhosphorMint else CyberCyan,
                        trackColor = DarkSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val mbDownloaded = downloadState.downloadedBytes / (1024 * 1024)
                        val mbTotal = downloadState.totalBytes / (1024 * 1024)
                        Text(
                            text = "$mbDownloaded MB / $mbTotal MB",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextSecondary
                        )

                        val speedMb = downloadState.speedBytesPerSec / (1024.0 * 1024.0)
                        Text(
                            text = if (downloadState.isCompleted) "SHA-256 Verified" else String.format("%.1f MB/s", speedMb),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = PhosphorMint
                        )
                    }

                    if (downloadState.isDownloading) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { viewModel.cancelSlimboxDownload() },
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Icon(Icons.Default.Cancel, contentDescription = null, modifier = Modifier.size(12.dp), tint = DangerCoral)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Cancel Download", fontSize = 11.sp, color = DangerCoral)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // SoC Filter chips
            Text("Filter by Chipset:", fontSize = 11.sp, color = TextTertiary)
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("All", "H616", "H313", "H618", "H6").forEach { soc ->
                    val isSelected = socFilter == soc
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) CyberCyan.copy(alpha = 0.2f) else DarkSurfaceVariant)
                            .border(1.dp, if (isSelected) CyberCyan else DarkBorder, RoundedCornerShape(6.dp))
                            .clickable { viewModel.setSocFilter(soc) }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = soc,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) CyberCyan else TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Filtered release cards
            val filteredReleases = availableReleases.filter {
                socFilter == "All" || it.targetSoc.contains(socFilter)
            }

            filteredReleases.forEach { rel ->
                val isCurrentlyDownloading = downloadState.isDownloading && downloadState.activeRelease?.id == rel.id

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkSurfaceVariant)
                        .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(rel.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(rel.targetSoc, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = CyberCyan)
                                Text("•", fontSize = 11.sp, color = TextTertiary)
                                Text(rel.androidVersion, fontSize = 11.sp, color = PhosphorMint)
                                Text("•", fontSize = 11.sp, color = TextTertiary)
                                Text("${rel.fileSizeBytes / (1024 * 1024)} MB", fontSize = 11.sp, color = TextSecondary)
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Button(
                                onClick = { viewModel.startSlimboxDownload(rel) },
                                enabled = !downloadState.isDownloading,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isCurrentlyDownloading) DarkSurfaceHighlight else CyberCyan,
                                    contentColor = Color(0xFF070A0E)
                                ),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.testTag("download_${rel.id}")
                            ) {
                                Icon(
                                    imageVector = if (isCurrentlyDownloading) Icons.Default.Download else Icons.Default.CloudDownload,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isCurrentlyDownloading) "${(downloadState.progress * 100).toInt()}%" else "Download & Flash",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedButton(
                                onClick = { viewModel.downloadViaSystemDownloadManager(rel) },
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.testTag("download_folder_${rel.id}")
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(12.dp), tint = TextSecondary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("To /Download", fontSize = 10.sp, color = TextSecondary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Boxes: ${rel.popularBoxes}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = rel.features.take(2).joinToString(" • "),
                        fontSize = 10.sp,
                        color = TextTertiary,
                        maxLines = 1
                    )
                }
            }
        }

        // DOWNLOAD FOLDER DISCOVERY & IMPORT (/sdcard/Download)
        CyberCard(borderColor = PhosphorMint) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Folder, contentDescription = null, tint = PhosphorMint, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "IMPORT FROM DOWNLOADS FOLDER",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = PhosphorMint,
                        letterSpacing = 0.5.sp
                    )
                }

                OutlinedButton(
                    onClick = { viewModel.scanDownloadsFolder() },
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("scan_downloads_btn")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp), tint = PhosphorMint)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Scan /Download", fontSize = 11.sp, color = PhosphorMint)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Images downloaded from slimboxtv.ru via your browser or DownloadManager are detected here. Tap 'Import & Flash' to load the .img file directly into the flasher.",
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            if (scannedDownloadImages.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkSurfaceVariant)
                        .padding(14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "No .img files found in Download folder yet.",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Download an image from slimboxtv.ru or use 'To /Download'. Tap 'Scan /Download' once saved.",
                            fontSize = 11.sp,
                            color = TextTertiary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                scannedDownloadImages.forEach { fileItem ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkSurfaceVariant)
                            .border(1.dp, if (fileItem.isSlimbox) PhosphorMint.copy(alpha = 0.5f) else DarkBorder, RoundedCornerShape(8.dp))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (fileItem.isSlimbox) Icons.Default.Tv else Icons.Default.InsertDriveFile,
                                contentDescription = null,
                                tint = if (fileItem.isSlimbox) PhosphorMint else CyberCyan,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = fileItem.name,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    maxLines = 1
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        text = "${fileItem.sizeBytes / (1024 * 1024)} MB",
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = TextSecondary
                                    )
                                    if (fileItem.isSlimbox) {
                                        Text("•", fontSize = 10.sp, color = TextTertiary)
                                        Text(
                                            text = "SlimboxTV Detected",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = PhosphorMint
                                        )
                                    }
                                }
                            }
                        }

                        Button(
                            onClick = { viewModel.importDownloadedImgFile(fileItem) },
                            colors = ButtonDefaults.buttonColors(containerColor = PhosphorMint, contentColor = Color(0xFF070A0E)),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.testTag("import_flash_${fileItem.name}")
                        ) {
                            Icon(Icons.Default.FlashOn, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Import & Flash", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // FIRMWARE SELECTION & PARTITION PARSER
        CyberCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.InsertDriveFile, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("TARGET FIRMWARE (.IMG)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CyberCyan)
                }

                OutlinedButton(
                    onClick = { filePickerLauncher.launch("*/*") },
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("browse_custom_img_btn")
                ) {
                    Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(14.dp), tint = CyberCyan)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Browse .img", fontSize = 11.sp, color = CyberCyan)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Presets row
            Text("SlimboxTV Quick Presets:", fontSize = 11.sp, color = TextTertiary)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Allwinner H616", "Allwinner H313", "Allwinner H6").forEach { soc ->
                    val isSelected = firmwareDetails?.targetSoC?.contains(soc.replace("Allwinner ", "")) == true
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) CyberCyan.copy(alpha = 0.2f) else DarkSurfaceVariant)
                            .border(1.dp, if (isSelected) CyberCyan else DarkBorder, RoundedCornerShape(6.dp))
                            .clickable { viewModel.loadSampleSlimboxTvFirmware(soc) }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = soc.replace("Allwinner ", ""),
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) CyberCyan else TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (firmwareDetails != null) {
                val fw = firmwareDetails!!
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkSurfaceVariant)
                        .padding(12.dp)
                ) {
                    Text(text = fw.fileName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text("Size: ${fw.fileSize / (1024 * 1024)} MB", fontSize = 11.sp, color = TextSecondary)
                        Text("Type: ${fw.firmwareType}", fontSize = 11.sp, color = CyberCyan)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Target: ${fw.targetSoC}", fontSize = 11.sp, color = PhosphorMint)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Validation: ${fw.validationMessage}",
                        fontSize = 11.sp,
                        color = if (fw.isCompatibleWithConnectedChip) PhosphorMint else WarningAmber
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Partitions breakdown table
                Text(
                    text = "IMAGE PARTITION MAP (${fw.partitions.size} Partitions)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                fw.partitions.forEach { part ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(DarkSurfaceVariant)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (part.isCritical) DangerCoral else CyberCyan)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = part.name,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    fontFamily = FontFamily.Monospace,
                                    color = TextPrimary
                                )
                                Text(
                                    text = part.description,
                                    fontSize = 10.sp,
                                    color = TextSecondary
                                )
                            }
                        }

                        Text(
                            text = "${part.sizeBytes / (1024 * 1024)} MB",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                }
            }
        }
    }
}

private fun getFileInfo(context: Context, uri: Uri): Pair<String, Long> {
    var name = "firmware.img"
    var size = 1024L * 1024 * 1024
    try {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex != -1) name = cursor.getString(nameIndex)
                if (sizeIndex != -1) size = cursor.getLong(sizeIndex)
            }
        }
    } catch (_: Exception) {}
    return Pair(name, size)
}
