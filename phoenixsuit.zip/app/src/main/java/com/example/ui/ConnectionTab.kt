package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Cable
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectionStatus
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DangerCoral
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.PhosphorMint
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.FlasherViewModel

import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material.icons.filled.Science

@Composable
fun ConnectionTab(
    viewModel: FlasherViewModel,
    modifier: Modifier = Modifier
) {
    val connectionStatus by viewModel.connectionStatus.collectAsState()
    val deviceInfo by viewModel.deviceInfo.collectAsState()
    val discoveredDevices by viewModel.discoveredDevices.collectAsState()
    val stabilityReport by viewModel.stabilityReport.collectAsState()
    val socMatchResult by viewModel.socMatchResult.collectAsState()
    val isSimulationMode by viewModel.isSimulationMode.collectAsState()
    var showGuide by remember { mutableStateOf(false) }

    val nonFelDevice = discoveredDevices.find { !it.isAllwinnerFel }
    val felDevice = discoveredDevices.find { it.isAllwinnerFel }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Simulation Mode Notice Banner (Only when simulation mode is active)
        if (isSimulationMode) {
            CyberCard(
                borderColor = WarningAmber,
                backgroundColor = WarningAmber.copy(alpha = 0.12f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Science,
                            contentDescription = null,
                            tint = WarningAmber,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "HARDWARE SIMULATION ACTIVE",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = WarningAmber
                            )
                            Text(
                                text = "Synthetic Allwinner H616 active for testing without cables.",
                                fontSize = 11.sp,
                                color = TextPrimary
                            )
                        }
                    }
                    OutlinedButton(
                        onClick = { viewModel.toggleSimulationMode() },
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("Disable", fontSize = 11.sp, color = WarningAmber)
                    }
                }
            }
        }

        // Status banner
        CyberCard(
            borderColor = when {
                connectionStatus == ConnectionStatus.BROM_HANDSHAKED || connectionStatus == ConnectionStatus.COMPLETED -> PhosphorMint
                connectionStatus == ConnectionStatus.FEL_CONNECTED || connectionStatus == ConnectionStatus.BACKING_UP || connectionStatus == ConnectionStatus.FLASHING -> CyberCyan
                connectionStatus == ConnectionStatus.ERROR -> DangerCoral
                else -> DarkBorder
            }
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isSimulationMode) "SIMULATED FEL CONNECTION" else "USB OTG HARDWARE CONNECTION",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSimulationMode) WarningAmber else TextSecondary,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = when (connectionStatus) {
                            ConnectionStatus.BROM_HANDSHAKED -> "FEL Ready • ${deviceInfo?.chipName ?: "Allwinner"}"
                            ConnectionStatus.FEL_CONNECTED -> "Allwinner Device Attached"
                            ConnectionStatus.DEVICE_FOUND_PERMISSION_REQUIRED -> "Grant USB Permission"
                            ConnectionStatus.DISCONNECTED -> if (discoveredDevices.isEmpty()) "No USB Device Connected" else "Device Not in FEL Mode"
                            ConnectionStatus.ERROR -> "USB Protocol Error"
                            else -> "Hardware Flasher Active"
                        },
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                StatusPill(status = connectionStatus)
            }

            // Warning if USB device is detected but NOT in FEL mode
            if (!isSimulationMode && connectionStatus == ConnectionStatus.DISCONNECTED && nonFelDevice != null && felDevice == null) {
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(WarningAmber.copy(alpha = 0.12f))
                        .border(1.dp, WarningAmber.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "USB device detected (${nonFelDevice.deviceName}), but it is NOT in FEL Mode. TV box must be in FEL mode (VID 0x1F3A, PID 0xEFE8) to flash.",
                            fontSize = 11.sp,
                            color = WarningAmber
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = DarkBorder)
            Spacer(modifier = Modifier.height(12.dp))

            // Action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { viewModel.scanUsbBus() },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("scan_usb_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color(0xFF070A0E)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Scan USB", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { viewModel.performFelHandshake() },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("handshake_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = PhosphorMint, contentColor = Color(0xFF070A0E)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("FEL Handshake", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Dedicated button to probe device info and verify SoC match
            Button(
                onClick = { viewModel.probeDeviceInfoAndVerifySoc() },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("probe_device_verify_soc_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = WarningAmber,
                    contentColor = Color(0xFF070A0E)
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(imageVector = Icons.Default.Security, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Get Device Info & Verify SoC Match", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }

            // Mode toggle row (Physical vs Simulation)
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isSimulationMode) Icons.Default.Science else Icons.Default.Cable,
                        contentDescription = null,
                        tint = if (isSimulationMode) WarningAmber else PhosphorMint,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isSimulationMode) "Mode: Simulation (Synthetic)" else "Mode: Physical USB OTG (Strict)",
                        fontSize = 11.sp,
                        color = if (isSimulationMode) WarningAmber else PhosphorMint
                    )
                }

                OutlinedButton(
                    onClick = { viewModel.toggleSimulationMode() },
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Text(
                        text = if (isSimulationMode) "Switch to Real USB" else "Test Simulation",
                        fontSize = 10.sp,
                        color = if (isSimulationMode) WarningAmber else CyberCyan
                    )
                }
            }
        }

        // SoC Match & Instant Abort Alert Card
        if (socMatchResult != null) {
            val res = socMatchResult!!
            if (res.isAborted) {
                // INSTANT ABORT CARD (Pulsing Red)
                CyberCard(
                    borderColor = DangerCoral,
                    backgroundColor = DangerCoral.copy(alpha = 0.12f)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Error, contentDescription = null, tint = DangerCoral, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "INSTANT ABORT: FATAL SoC MISMATCH!",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                color = DangerCoral,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "Flashing locked to prevent permanently bricking the TV box.",
                                fontSize = 11.sp,
                                color = TextPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkBackground)
                            .border(1.dp, DangerCoral.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text("Connected Hardware: ${res.connectedSoc}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DangerCoral)
                            Text("Target Firmware Image: ${res.imageSoc}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = WarningAmber)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = res.detailedReport,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TextSecondary,
                                lineHeight = 14.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { viewModel.dismissSocMatchDialog() },
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Acknowledge & Dismiss", fontSize = 11.sp, color = DangerCoral)
                    }
                }
            } else {
                // SUCCESS SOC MATCH CARD (Green)
                CyberCard(
                    borderColor = PhosphorMint,
                    backgroundColor = PhosphorMint.copy(alpha = 0.08f)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PhosphorMint, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "SoC MATCH CONFIRMED (SAFE TO FLASH)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = PhosphorMint
                            )
                            Text(
                                text = "Connected hardware strictly matches target firmware image.",
                                fontSize = 11.sp,
                                color = TextPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkBackground)
                            .border(1.dp, PhosphorMint.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = res.detailedReport,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = PhosphorMint,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }

        // Chip Specifications & Registers Card
        if (deviceInfo != null) {
            CyberCard(borderColor = CyberCyan.copy(alpha = 0.5f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Memory, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("CHIP IDENTIFICATION & REGISTERS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CyberCyan)
                }
                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricBox(
                        title = "SoC",
                        value = deviceInfo!!.chipName.replace("Allwinner ", ""),
                        icon = Icons.Default.Memory,
                        accentColor = CyberCyan,
                        modifier = Modifier.weight(1f)
                    )
                    MetricBox(
                        title = "BROM HWID",
                        value = deviceInfo!!.bromVersionHex,
                        icon = Icons.Default.Bolt,
                        accentColor = PhosphorMint,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricBox(
                        title = "eMMC Storage",
                        value = "${deviceInfo!!.emmcCapacityMb / 1024}",
                        unit = "GB",
                        icon = Icons.Default.Storage,
                        accentColor = WarningAmber,
                        modifier = Modifier.weight(1f)
                    )
                    MetricBox(
                        title = "USB Mode",
                        value = "AWUC Bulk",
                        icon = Icons.Default.Usb,
                        accentColor = CyberCyan,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Architecture: ${deviceInfo!!.chipArchitecture}",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
                Text(
                    text = "DRAM State: ${deviceInfo!!.dramStatus}",
                    fontSize = 11.sp,
                    color = PhosphorMint,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Connection Stability & Diagnostic Check (User Request)
        CyberCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.NetworkCheck, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("CONNECTION STABILITY TEST", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
                OutlinedButton(
                    onClick = { viewModel.runStabilityDiagnostics() },
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("test_stability_btn")
                ) {
                    Text("Test Link", fontSize = 11.sp, color = CyberCyan)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (stabilityReport != null) {
                val rep = stabilityReport!!
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricBox(
                        title = "Latency",
                        value = if (rep.roundTripLatencyMs >= 0) "${rep.roundTripLatencyMs}" else "N/A",
                        unit = "ms",
                        icon = Icons.Default.Speed,
                        accentColor = if (rep.isStable) PhosphorMint else DangerCoral,
                        modifier = Modifier.weight(1f)
                    )
                    MetricBox(
                        title = "Packet Loss",
                        value = "${rep.packetLossPercent.toInt()}%",
                        icon = Icons.Default.NetworkCheck,
                        accentColor = if (rep.packetLossPercent == 0f) PhosphorMint else DangerCoral,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = rep.statusMessage,
                    fontSize = 12.sp,
                    color = if (rep.isStable) PhosphorMint else WarningAmber
                )
                Text(
                    text = "Power: ${rep.powerState}",
                    fontSize = 11.sp,
                    color = TextTertiary
                )
            } else {
                Text(
                    text = "Run diagnostic probe to verify USB OTG cable integrity, VBUS power drops, and transfer latency.",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
        }

        // Attached USB Devices Scan Output
        CyberCard {
            Text(
                text = "USB BUS ENUMERATION (${discoveredDevices.size})",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (discoveredDevices.isEmpty()) {
                Text(
                    text = "No USB devices detected on Android OTG port.\nEnsure USB OTG adapter is enabled in system settings.",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 16.sp
                )
            } else {
                discoveredDevices.forEach { dev ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (dev.isAllwinnerFel) DarkSurfaceHighlight else DarkSurfaceVariant)
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (dev.isAllwinnerFel) Icons.Default.Bolt else Icons.Default.Usb,
                            contentDescription = null,
                            tint = if (dev.isAllwinnerFel) CyberCyan else TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = dev.productName ?: "USB Device",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (dev.isAllwinnerFel) CyberCyan else TextPrimary
                            )
                            Text(
                                text = "VID: 0x${Integer.toHexString(dev.vendorId).padStart(4, '0')}  PID: 0x${Integer.toHexString(dev.productId).padStart(4, '0')} (${dev.deviceName})",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }

        // FEL Mode Trigger Guide Card (Accordion)
        CyberCard(backgroundColor = DarkSurfaceVariant) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showGuide = !showGuide },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.HelpOutline, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("How to Enter FEL Mode on TV Box", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
                Text(if (showGuide) "Hide" else "Show", fontSize = 12.sp, color = CyberCyan)
            }

            AnimatedVisibility(visible = showGuide) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    Text(
                        text = "1. AV Jack Method (Standard):\n" +
                               "Insert a wooden toothpick into the 3.5mm AV jack on the back of the TV box until you feel the hidden tactile switch click. Hold it pressed, plug in the USB OTG cable from your phone into the USB-1 / OTG port, and then release after 3 seconds.\n\n" +
                               "2. Recovery Button Method:\n" +
                               "On boxes like Tanix TX6s, hold the bottom recovery button while connecting the OTG cable.\n\n" +
                               "3. Clock/eMMC Test-Point Method:\n" +
                               "For hard-bricked boxes where BROM does not enter FEL, open the case and momentarily bridge the CLK test-point to GND with tweezers while inserting the USB cable.\n\n" +
                               "4. Software Command:\n" +
                               "If the TV box still boots Android, run 'reboot efex' via Termux or ADB.",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}
