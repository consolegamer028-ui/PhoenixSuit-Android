package com.example.fel

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Binary protocol packet builder and parser for Allwinner FEL Mode and PhoenixSuit USB transfers.
 */
object FelPacket {

    /**
     * Builds a 16-byte AWUC command packet.
     * Allwinner FEL expects little-endian integers.
     */
    fun createAwucCommand(
        command: Int,
        address: Int = 0,
        length: Int = 0,
        tag: Int = 0x1234
    ): ByteArray {
        val buffer = ByteBuffer.allocate(16).order(ByteOrder.LITTLE_ENDIAN)
        buffer.put(AllwinnerConstants.FEL_MAGIC_AWUC) // 4 bytes: 'A','W','U','C'
        buffer.putInt(tag)                            // 4 bytes: tag
        buffer.putInt(length)                         // 4 bytes: data length
        buffer.putShort(0.toShort())                  // 2 bytes: flags
        buffer.putShort(command.toShort())            // 2 bytes: command opcode
        return buffer.array()
    }

    /**
     * Builds a 32-byte FEL extended read/write request.
     */
    fun createMemoryRequest(
        command: Int,
        address: Long,
        length: Long,
        tag: Int = 0x5678
    ): ByteArray {
        val buffer = ByteBuffer.allocate(32).order(ByteOrder.LITTLE_ENDIAN)
        buffer.put(AllwinnerConstants.FEL_MAGIC_AWUC)
        buffer.putInt(tag)
        buffer.putInt(length.toInt())
        buffer.putShort(0.toShort())
        buffer.putShort(command.toShort())
        buffer.putInt(address.toInt())
        buffer.putInt(length.toInt())
        buffer.put(ByteArray(8)) // padding
        return buffer.array()
    }

    /**
     * Validates if response begins with "AWUS" (Allwinner Status Token)
     */
    fun parseAwusResponse(response: ByteArray): AwusResult {
        if (response.size < 13) {
            return AwusResult(success = false, tag = 0, status = -1, residue = 0)
        }
        val buffer = ByteBuffer.wrap(response).order(ByteOrder.LITTLE_ENDIAN)
        val magic = ByteArray(4)
        buffer.get(magic)
        val isAwus = magic.contentEquals(AllwinnerConstants.FEL_MAGIC_AWUS)
        val tag = buffer.int
        val residue = buffer.int
        val status = buffer.get().toInt()
        return AwusResult(
            success = isAwus && status == 0,
            tag = tag,
            status = status,
            residue = residue
        )
    }

    data class AwusResult(
        val success: Boolean,
        val tag: Int,
        val status: Int,
        val residue: Int
    )

    /**
     * Parses the 32-byte VERIFY_DEV payload returned by Allwinner BROM.
     */
    fun parseBromVersion(data: ByteArray): Int {
        if (data.size < 8) return 0x00185100 // fallback to H616 default
        val buffer = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        // Usually at offset 4 or 0 in the chip version buffer
        return try {
            buffer.int
        } catch (_: Exception) {
            0x00185100
        }
    }

    /**
     * Formats a byte array as a hex string for hardware terminal logs.
     */
    fun toHexString(bytes: ByteArray, maxBytes: Int = 32): String {
        val limit = minOf(bytes.size, maxBytes)
        val sb = StringBuilder()
        for (i in 0 until limit) {
            sb.append(String.format("%02X ", bytes[i]))
        }
        if (bytes.size > maxBytes) {
            sb.append("... (+${bytes.size - maxBytes} bytes)")
        }
        return sb.toString().trim()
    }
}
