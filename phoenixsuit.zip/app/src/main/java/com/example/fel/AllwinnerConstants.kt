package com.example.fel

/**
 * Low-level hardware constants for Allwinner BROM / FEL Mode and PhoenixSuit USB protocol.
 */
object AllwinnerConstants {
    // USB Vendor & Product IDs
    const val USB_VENDOR_ALLWINNER = 0x1f3a // Decimal: 7994
    const val USB_PRODUCT_FEL = 0xefe8      // Decimal: 61416 (Standard Allwinner FEL mode)
    const val USB_PRODUCT_FASTBOOT = 0x1010 // Decimal: 4112 (Fastboot / PhoenixSuit secondary)
    const val USB_PRODUCT_ADB = 0x1002      // Decimal: 4098 (Android USB Debugging mode)
    const val USB_PRODUCT_MTP = 0x4e88      // Decimal: 20104 (Android MTP storage mode)

    fun isAllwinnerFel(vendorId: Int, productId: Int): Boolean {
        return vendorId == USB_VENDOR_ALLWINNER && (productId == USB_PRODUCT_FEL || productId == USB_PRODUCT_FASTBOOT)
    }

    fun isAllwinnerNonFel(vendorId: Int, productId: Int): Boolean {
        return vendorId == USB_VENDOR_ALLWINNER && !isAllwinnerFel(vendorId, productId)
    }

    // Allwinner FEL Standard Magic Signature ("AWUC" - Allwinner USB Communication)
    val FEL_MAGIC_AWUC = byteArrayOf(0x41, 0x57, 0x55, 0x43) // "AWUC"
    val FEL_MAGIC_AWUS = byteArrayOf(0x41, 0x57, 0x55, 0x53) // "AWUS" response token

    // Standard FEL Commands
    const val FEL_CMD_VERIFY_DEV = 0x0001
    const val FEL_CMD_SWITCH_ROLE = 0x0002
    const val FEL_CMD_IS_READY = 0x0003
    const val FEL_CMD_PROBE_DRAM = 0x0004
    const val FEL_CMD_READ = 0x0011
    const val FEL_CMD_WRITE = 0x0012
    const val FEL_CMD_EXEC = 0x0013
    const val FEL_CMD_REBOOT = 0x0018
    const val FEL_CMD_PHOENIX_FLASH = 0x0019

    // Allwinner Chipset Hardware IDs & Names
    val KNOWN_CHIPSETS = mapOf(
        0x00185100 to ChipInfo("Allwinner H616", "ARM Cortex-A53 Quad-Core, Mali-G31 MP2", "Tanix TX6s, T95, X96Q, SlimboxTV H616", 0x1851),
        0x00185500 to ChipInfo("Allwinner H618", "ARM Cortex-A53 Quad-Core, Mali-G31 MP2", "T95Z Plus, Transpeed 618, SlimboxTV H618", 0x1855),
        0x00182300 to ChipInfo("Allwinner H313", "ARM Cortex-A53 Quad-Core, Mali-G31 MP2", "X96Q, Tanix TX1, X96 Mini v2, SlimboxTV H313", 0x1823),
        0x00168900 to ChipInfo("Allwinner H6", "ARM Cortex-A53 Quad-Core, Mali-T720 MP2", "Eachlink H6 Mini, Beelink GS1, Tanix TX6", 0x1689),
        0x00168000 to ChipInfo("Allwinner H3", "ARM Cortex-A7 Quad-Core, Mali-400 MP2", "Orange Pi One/PC, Sunvell T95M, MXQ Pro H3", 0x1680),
        0x00167300 to ChipInfo("Allwinner H2+", "ARM Cortex-A7 Quad-Core", "Orange Pi Zero, Banana Pi M2 Zero", 0x1673),
        0x00168100 to ChipInfo("Allwinner A64", "ARM Cortex-A53 Quad-Core", "Pine64, Sopine, Pinetab", 0x1681)
    )

    data class ChipInfo(
        val name: String,
        val architecture: String,
        val popularBoxes: String,
        val chipCode: Int
    )

    fun identifyChip(bromVersion: Int): ChipInfo {
        return KNOWN_CHIPSETS[bromVersion] ?: ChipInfo(
            name = "Allwinner SoC (0x${bromVersion.toString(16).padStart(8, '0')})",
            architecture = "ARM Cortex Architecture",
            popularBoxes = "Universal Allwinner TV Box / SBC",
            chipCode = (bromVersion shr 8) and 0xFFFF
        )
    }
}
