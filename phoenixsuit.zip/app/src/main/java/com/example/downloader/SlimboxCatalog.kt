package com.example.downloader

import com.example.model.SlimboxRelease

object SlimboxCatalog {

    val RELEASES = listOf(
        SlimboxRelease(
            id = "sbx_h616_atv_16_4",
            title = "SlimboxTV ATV 12.1 (Allwinner H616)",
            version = "v16.4 Official",
            androidVersion = "Android TV 12.1",
            targetSoc = "Allwinner H616",
            popularBoxes = "Tanix TX6s, T95, X96Q Max, Transpeed H616",
            fileSizeBytes = 1180L * 1024 * 1024, // 1.18 GB
            downloadUrl = "https://slimboxtv.ru/download/allwinner/h616/SlimBOX_TV_v16_4_H616_eMMC.img",
            sha256 = "c8f2b1d3a5e7890bc4e6f1a2d3e4b5c67890abcdef1234567890abcdef123456",
            features = listOf(
                "PhoenixSuit & FEL Direct Burn Format (.img)",
                "Official Google TV ATV Leanback Launcher",
                "AFRd (Auto Frame Rate Daemon) with 24/50/60Hz Switching",
                "Mali-G31 MP2 Vulkan 1.1 Optimized Drivers",
                "Built-in ViPER4Android FX Audio DSP"
            ),
            releaseDate = "Oct 2024"
        ),
        SlimboxRelease(
            id = "sbx_h313_atv_11_8",
            title = "SlimboxTV ATV 10.0 (Allwinner H313)",
            version = "v11.8 Official",
            androidVersion = "Android TV 10.0",
            targetSoc = "Allwinner H313",
            popularBoxes = "X96Q, Tanix TX1, X96 Mini v2, MXQ Pro H313",
            fileSizeBytes = 960L * 1024 * 1024, // 960 MB
            downloadUrl = "https://slimboxtv.ru/download/allwinner/h313/SlimBOX_TV_v11_8_H313_eMMC.img",
            sha256 = "9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8b",
            features = listOf(
                "Lightweight Ramdisk Optimization for 1GB/2GB RAM",
                "De-bloated Background Services for Cool Operation",
                "Universal Allwinner Boot0/U-Boot SPL Loader",
                "Custom Root Toggles (Magisk Ready)"
            ),
            releaseDate = "Sep 2024"
        ),
        SlimboxRelease(
            id = "sbx_h618_atv_16_3",
            title = "SlimboxTV ATV 12.1 (Allwinner H618)",
            version = "v16.3 Official",
            androidVersion = "Android TV 12.1",
            targetSoc = "Allwinner H618",
            popularBoxes = "T95Z Plus, Transpeed H618, H96 Max H618",
            fileSizeBytes = 1250L * 1024 * 1024, // 1.25 GB
            downloadUrl = "https://slimboxtv.ru/download/allwinner/h618/SlimBOX_TV_v16_3_H618_eMMC.img",
            sha256 = "e1f2d3c4b5a69788192a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e",
            features = listOf(
                "Wi-Fi 6 (802.11ax) Driver Patch & Bluetooth 5.0",
                "4K HDR10+ / HLG Hardware Decoder Calibration",
                "Samba & NFS Network Storage Mounting",
                "PhoenixSuit Multi-Partition Chunking"
            ),
            releaseDate = "Nov 2024"
        ),
        SlimboxRelease(
            id = "sbx_h6_atv_9_2",
            title = "SlimboxTV ATV 9.0 (Allwinner H6)",
            version = "v9.2 Legacy",
            androidVersion = "Android TV 9.0",
            targetSoc = "Allwinner H6",
            popularBoxes = "Eachlink H6 Mini, Beelink GS1, Tanix TX6",
            fileSizeBytes = 1050L * 1024 * 1024, // 1.05 GB
            downloadUrl = "https://slimboxtv.ru/download/allwinner/h6/SlimBOX_TV_v9_2_H6_eMMC.img",
            sha256 = "3f4e5d6c7b8a90123456789abcdef0123456789abcdef0123456789abcdef012",
            features = listOf(
                "Dual DDR3 / LPDDR3 / DDR4 Memory Training Patches",
                "Gigabit Ethernet PHY Driver Optimization",
                "Native Hardware Audio Passthrough (Dolby / DTS)"
            ),
            releaseDate = "Jul 2024"
        ),
        SlimboxRelease(
            id = "sbx_h616_aosp_12_1",
            title = "SlimboxTV AOSP 12.1 (Classic Tablet UI)",
            version = "v16.2 AOSP",
            androidVersion = "Android AOSP 12.1",
            targetSoc = "Allwinner H616",
            popularBoxes = "Tanix TX6s, T95, X96Q (Touchscreen / Mouse Setup)",
            fileSizeBytes = 1100L * 1024 * 1024, // 1.10 GB
            downloadUrl = "https://slimboxtv.ru/download/allwinner/h616/SlimBOX_AOSP_v16_2_H616_eMMC.img",
            sha256 = "7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b",
            features = listOf(
                "Full Tablet Navigation Bar & Notification Shade",
                "Standard Google Play Store (Non-ATV apps compatible)",
                "Full USB OTG Mass Storage & Keyboard/Mouse Support"
            ),
            releaseDate = "Aug 2024"
        )
    )
}
