package com.example.downloader

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import java.io.File

data class DownloadedImgFile(
    val name: String,
    val file: File,
    val sizeBytes: Long,
    val lastModifiedMs: Long,
    val isSlimbox: Boolean
)

class DownloadFolderManager(private val context: Context) {

    private val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    /**
     * Enqueues download to system Download folder via Android DownloadManager.
     */
    fun enqueueToDownloadsFolder(
        downloadUrl: String,
        fileName: String,
        description: String = "SlimboxTV Image for Allwinner TV Box"
    ): Long {
        return try {
            val request = DownloadManager.Request(Uri.parse(downloadUrl))
                .setTitle(fileName)
                .setDescription(description)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)

            downloadManager.enqueue(request)
        } catch (_: Exception) {
            -1L
        }
    }

    /**
     * Scans Android public Downloads folder and app external folders for .img firmware files.
     */
    fun scanDownloadFolderForImages(): List<DownloadedImgFile> {
        val results = mutableListOf<DownloadedImgFile>()
        val searchDirs = listOfNotNull(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
            context.getExternalFilesDir("firmware"),
            File("/sdcard/Download")
        )

        val seenPaths = mutableSetOf<String>()

        for (dir in searchDirs) {
            if (dir.exists() && dir.isDirectory) {
                val files = dir.listFiles { f ->
                    f.isFile && (f.name.endsWith(".img", ignoreCase = true) || f.name.contains("slimbox", ignoreCase = true))
                } ?: emptyArray()

                for (file in files) {
                    if (seenPaths.add(file.absolutePath)) {
                        results.add(
                            DownloadedImgFile(
                                name = file.name,
                                file = file,
                                sizeBytes = file.length(),
                                lastModifiedMs = file.lastModified(),
                                isSlimbox = file.name.contains("slimbox", ignoreCase = true) || file.name.contains("sbx", ignoreCase = true)
                            )
                        )
                    }
                }
            }
        }

        // Return sorted by most recently modified
        return results.sortedByDescending { it.lastModifiedMs }
    }

    /**
     * Launches external web browser to official slimboxtv.ru portal.
     */
    fun openSlimboxWebsite(url: String = "https://slimboxtv.ru/"): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }
}
